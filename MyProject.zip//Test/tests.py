Great job john!
It works!
